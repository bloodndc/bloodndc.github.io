/* register.js — donor registration / profile update with validation */
import { doc, getDoc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";
import { db, ensureAuth } from "./firebase.js";
import {
  $, $$, BLOOD_GROUPS, isValidBDPhone, normalizePhone, roundCoord,
  toast, showConnectError, fmtDate
} from "./ui.js";

const form = $("#donorForm");
let currentUser = null;
let existingDoc = null;

/* ---------- setup ---------- */
$("#fGroup").innerHTML =
  '<option value="" disabled selected>Select your blood group</option>' +
  BLOOD_GROUPS.map((g) => `<option value="${g}">${g}</option>`).join("");
$("#fLast").max = new Date().toISOString().slice(0, 10);

/* ---------- prefill if this browser already has a donor profile ---------- */
async function init() {
  try {
    currentUser = await ensureAuth();
    const ref = doc(db, "donors", currentUser.uid);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      existingDoc = snap.data();
      $("#pageTitle").innerHTML = 'Update your <em class="accent">profile</em>';
      $("#submitBtn").textContent = "Save changes";
      $("#fName").value = existingDoc.name || "";
      $("#fGroup").value = existingDoc.bloodGroup || "";
      $("#fPhone").value = existingDoc.phone || "";
      $("#fArea").value = existingDoc.area || "";
      $("#fCity").value = existingDoc.city || "Dhaka";
      $("#fLast").value = existingDoc.lastDonation || "";
      $("#fAvailable").checked = existingDoc.available !== false;
      $("#fConsent").checked = true;
      if (existingDoc.lat != null && existingDoc.lng != null) {
        $("#fLat").value = existingDoc.lat;
        $("#fLng").value = existingDoc.lng;
        $("#geoLabel").textContent = "✓ Location saved";
      }
      toast("Welcome back! You can update your details below.", "success");
    }
  } catch (err) {
    showConnectError(err);
  }
}

/* ---------- location sharing ---------- */
$("#geoBtn").addEventListener("click", () => {
  if ($("#fLat").value) {
    // toggle off
    $("#fLat").value = ""; $("#fLng").value = "";
    $("#geoLabel").textContent = "Share my approximate location";
    toast("Location removed from your profile.");
    return;
  }
  if (!navigator.geolocation) {
    toast("Geolocation is not supported by this browser.", "error");
    return;
  }
  $("#geoLabel").textContent = "Locating…";
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      $("#fLat").value = roundCoord(pos.coords.latitude);
      $("#fLng").value = roundCoord(pos.coords.longitude);
      $("#geoLabel").textContent = "✓ Location saved (≈1 km precision)";
      toast("Approximate location added — thank you!", "success");
    },
    () => {
      $("#geoLabel").textContent = "Share my approximate location";
      toast("Could not get your location. You can still register without it.", "error");
    },
    { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
  );
});

/* ---------- validation ---------- */
function setInvalid(input, bad) {
  input.closest(".field")?.classList.toggle("invalid", bad);
  return !bad;
}

function validate() {
  const name = $("#fName").value.trim();
  const group = $("#fGroup").value;
  const phone = normalizePhone($("#fPhone").value);
  const area = $("#fArea").value.trim();
  const last = $("#fLast").value;

  let ok = true;
  ok = setInvalid($("#fName"), name.length < 3) && ok;
  ok = setInvalid($("#fGroup"), !BLOOD_GROUPS.includes(group)) && ok;
  ok = setInvalid($("#fPhone"), !isValidBDPhone(phone)) && ok;
  ok = setInvalid($("#fArea"), !area) && ok;
  ok = setInvalid($("#fLast"), !!last && new Date(last) > new Date()) && ok;

  const consentErr = $("#consentError");
  if (!$("#fConsent").checked) {
    consentErr.style.display = "block";
    ok = false;
  } else {
    consentErr.style.display = "none";
  }
  return ok;
}

// live re-validation
["fName", "fGroup", "fPhone", "fArea", "fLast"].forEach((id) => {
  $("#" + id).addEventListener("input", (e) => setInvalid(e.target, false));
});

/* ---------- submit ---------- */
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!validate()) {
    toast("Please fix the highlighted fields.", "error");
    $(".invalid input, .invalid select")?.focus();
    return;
  }

  const btn = $("#submitBtn");
  btn.disabled = true;
  btn.innerHTML = '<span class="spin" aria-hidden="true"></span> Saving…';

  try {
    if (!currentUser) currentUser = await ensureAuth();

    const phone = normalizePhone($("#fPhone").value);
    const lat = $("#fLat").value ? Number($("#fLat").value) : null;
    const lng = $("#fLng").value ? Number($("#fLng").value) : null;

    const data = {
      name: $("#fName").value.trim(),
      bloodGroup: $("#fGroup").value,
      phone,
      area: $("#fArea").value.trim(),
      city: $("#fCity").value.trim() || "Dhaka",
      lastDonation: $("#fLast").value || null,
      available: $("#fAvailable").checked,
      lat, lng,
      updatedAt: serverTimestamp()
    };

    const ref = doc(db, "donors", currentUser.uid);
    if (existingDoc) {
      // keep moderator flag; never allow self-verification
      data.verified = !!existingDoc.verified;
      data.createdAt = existingDoc.createdAt || serverTimestamp();
    } else {
      data.verified = false;
      data.createdBy = currentUser.uid;
      data.createdAt = serverTimestamp();
    }

    await setDoc(ref, data);

    toast(
      existingDoc ? "Your profile has been updated. Thank you! ❤" : "You're registered! Thank you for joining NDC Lifeline. ❤",
      "success",
      6000
    );
    setTimeout(() => (location.href = "donors.html"), 1200);
  } catch (err) {
    showConnectError(err);
    toast("Could not save your registration. Please try again.", "error");
    btn.disabled = false;
    btn.textContent = existingDoc ? "Save changes" : "Register as a donor";
  }
});

init();
