/* home.js — stats, urgent requests preview, eligibility checker, group chips */
import { collection, getDocs, query, where } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";
import { db, ensureAuth } from "./firebase.js";
import { $, BLOOD_GROUPS, esc, eligibility, fmtDate, countUp, toast, showConnectError } from "./ui.js";

function donorFromDoc(d) {
  return { id: d.id, ...(d.data() || {}) };
}

function requestCardHTML(r) {
  const days = Math.ceil((new Date(r.neededBy + "T23:59:59") - Date.now()) / 86400000);
  const urgency =
    days <= 0 ? '<span class="urgency hot">Needed today</span>'
    : days === 1 ? '<span class="urgency hot">Needed tomorrow</span>'
    : `<span class="urgency warm">Within ${days} days</span>`;
  return `
  <article class="card pad req-card hover">
    <div class="req-head">
      <span class="bg-badge bg-${r.bloodGroup.replace("+", "").replace("-", "")}">${esc(r.bloodGroup)}</span>
      <div>
        <div class="donor-name">${esc(r.hospital || "Hospital not specified")}</div>
        <div class="donor-meta">${esc(r.area || "Dhaka")} · ${r.units || 1} unit(s) · needed by <b>${fmtDate(r.neededBy)}</b></div>
      </div>
    </div>
    <div class="donor-tags">${urgency}<span class="badge badge-red">Emergency</span></div>
    <div class="donor-actions">
      <a class="btn btn-outline btn-sm" href="requests.html">Details &amp; contact →</a>
    </div>
  </article>`;
}

async function loadHome() {
  try {
    await ensureAuth();

    const [donorSnap, reqSnap] = await Promise.all([
      getDocs(collection(db, "donors")),
      getDocs(query(collection(db, "requests"), where("status", "==", "active")))
    ]);

    const donors = donorSnap.docs.map(donorFromDoc);
    const requests = reqSnap.docs.map((d) => ({ id: d.id, ...(d.data() || {}) }));

    const eligibleCount = donors.filter((d) => d.available !== false && eligibility(d.lastDonation).eligible).length;
    const active = requests.filter((r) => new Date(r.neededBy + "T23:59:59") >= new Date(Date.now() - 86400000));

    // hero numbers
    $("#statDonors").textContent = donors.length;
    $("#statEligible").textContent = eligibleCount;
    $("#statRequests").textContent = active.length;

    // stats band (fulfilled counted separately)
    const allReq = await getDocs(collection(db, "requests"));
    const fulfilledCount = allReq.docs.filter((d) => d.data()?.status === "fulfilled").length;
    countUp($("#bandDonors"), donors.length);
    countUp($("#bandEligible"), eligibleCount);
    countUp($("#bandActive"), active.length);
    countUp($("#bandFulfilled"), fulfilledCount);

    // urgent preview — soonest needed-by first, max 3
    const urgentList = $("#urgentList");
    const sorted = [...requests]
      .filter((r) => new Date(r.neededBy + "T23:59:59") >= new Date(Date.now() - 86400000))
      .sort((a, b) => (a.neededBy || "").localeCompare(b.neededBy || ""))
      .slice(0, 3);

    if (!sorted.length) {
      urgentList.innerHTML = `
        <div class="empty-state" style="grid-column:1/-1">
          <svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
          <h3>No active emergency requests</h3>
          <p>Good news — nobody needs urgent help right now.<br>If an emergency comes up, <a href="requests.html">post a request</a>.</p>
        </div>`;
    } else {
      urgentList.innerHTML = sorted.map(requestCardHTML).join("");
    }
  } catch (err) {
    showConnectError(err);
    const urgentList = $("#urgentList");
    if (urgentList) urgentList.innerHTML = "";
  }
}

function initGroupChips() {
  const wrap = $("#groupChips");
  if (!wrap) return;
  wrap.innerHTML = BLOOD_GROUPS.map((g) => {
    const base = g.replace("+", "").replace("-", "");
    return `
    <a class="group-tile" href="donors.html?group=${encodeURIComponent(g)}">
      <span class="bg-badge sm bg-${base}">${g}</span>
      <span class="gt-label">Find donors →</span>
    </a>`;
  }).join("");
}

function initEligibilityChecker() {
  const input = $("#eligDate");
  const box = $("#eligResult");
  if (!input || !box) return;
  input.max = new Date().toISOString().slice(0, 10);

  input.addEventListener("change", () => {
    if (!input.value) return;
    const res = eligibility(input.value);
    if (res.eligible) {
      box.className = "elig-result ok";
      box.innerHTML = `<div><div class="big">✓ You are eligible to donate</div>
        <p class="muted small mt-1">${res.known ? `Your 120-day gap has passed (last donation ${fmtDate(input.value)}). Thank you for saving lives!` : ""}</p>
        <a class="btn btn-primary btn-sm mt-2" href="donors.html">See active requests</a></div>`;
    } else {
      box.className = "elig-result wait";
      box.innerHTML = `<div><div class="big">Wait ${res.daysLeft} more day${res.daysLeft === 1 ? "" : "s"}</div>
        <p class="muted small mt-1">You'll be eligible again on <b>${fmtDate(res.nextDate)}</b>. Rest well and donate then!</p></div>`;
    }
  });
}

initGroupChips();
initEligibilityChecker();
loadHome();
