/* NDC Lifeline — Firebase bootstrap (Auth: anonymous · DB: Firestore) */
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
import { getAuth, signInAnonymously, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";

export const firebaseConfig = {
  apiKey: "AIzaSyA1cYpcameCImAE4pTbD8aa3uZivrgrPN0",
  authDomain: "blood-donate-ndc.firebaseapp.com",
  projectId: "blood-donate-ndc",
  storageBucket: "blood-donate-ndc.firebasestorage.app",
  messagingSenderId: "1062995040448",
  appId: "1:1062995040448:web:946760282dc16ce4b63525",
  measurementId: "G-XQKW1QTBFB"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

let authPromise = null;

/**
 * Resolves with the current user, signing in anonymously if needed.
 * Rejects if anonymous sign-in is disabled or the network call fails.
 */
export function ensureAuth() {
  if (authPromise) return authPromise;
  authPromise = new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      authPromise = null;
      reject(new Error("auth-timeout"));
    }, 15000);

    const unsub = onAuthStateChanged(
      auth,
      (user) => {
        if (user) {
          clearTimeout(timer);
          resolve(user);
        } else {
          signInAnonymously(auth)
            .then((cred) => {
              clearTimeout(timer);
              resolve(cred.user);
            })
            .catch((err) => {
              clearTimeout(timer);
              authPromise = null;
              reject(err);
            });
        }
      },
      (err) => {
        clearTimeout(timer);
        authPromise = null;
        reject(err);
      }
    );
    // Keep the listener alive only until first resolution.
    authPromise && authPromise.finally?.(() => unsub());
  });
  return authPromise;
}
