/* requests.js — emergency request board + posting */
import {
  collection, onSnapshot, addDoc, doc, updateDoc, deleteDoc, serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";
import { db, ensureAuth } from "./firebase.js";
import {
  $, $$, BLOOD_GROUPS, esc, fmtDate, isValidBDPhone, normalizePhone,
  toast, waShare, fbShare, showConnectError
} from "./ui.js";

let requests = [];
let currentUid = null;

const statusOf = (r) => {
  if (r.status === "fulfilled") return "fulfilled";
  if (new Date(r.neededBy + "T23:59:59") < new Date()) return "expired";
  return "active";
};

/* ---------- rendering ---------- */
function requestCardHTML(r) {
  const st = statusOf(r);
  const days = Math.ceil((new Date(r.neededBy + "T23:59:59") - Date.now()) / 86400000);

  const urgency =
    st !== "active" ? ""
    : days <= 0 ? '<span class="urgency hot">⏰ Needed today</span>'
    : days === 1 ? '<span class="urgency hot">⏰ Needed tomorrow</span>'
    : `<span class="urgency warm">Within ${days} days</span>`;

  const statusBadge =
    st === "fulfilled" ? '<span class="badge badge-green">✓ Fulfilled</span>'
    : st === "expired" ? '<span class="badge badge-gray">Expired</span>'
    : '<span class="badge badge-red">Emergency</span>';

  const shareText =
    `🩸 URGENT: ${r.bloodGroup} blood needed (${r.units || 1} unit) at ${r.hospital}${r.area ? ", " + r.area : ""} by ${fmtDate(r.neededBy)}.` +
    ` Contact ${r.contactName}: ${r.phone} — via NDC Lifeline (https://bloodndc.github.io/requests.html)`;

  const mine = currentUid && r.createdBy === currentUid && st === "active";

  return `
  <article class="card pad req-card hover ${st}">
    <div class="req-head">
      <span class="bg-badge bg-${r.bloodGroup.replace("+", "").replace("-", "")}">${esc(r.bloodGroup)}</span>
      <div>
        <div class="donor-name">${r.units || 1} unit(s) needed</div>
        <div class="donor-meta">Posted ${fmtDate(r.createdAt)}</div>
      </div>
    </div>
    <div class="req-meta">
      <div class="row"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18M5 21V8l7-5 7 5v13M9 21v-6h6v6"/></svg><span><b>${esc(r.hospital)}</b>${r.area ? " · " + esc(r.area) : ""}</span></div>
      <div class="row"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg><span>Needed by <b>${fmtDate(r.neededBy)}</b> ${urgency}</span></div>
      ${r.patient ? `<div class="row"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/></svg><span>${esc(r.patient)}</span></div>` : ""}
      <div class="row"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg><span>Contact: <b>${esc(r.contactName)}</b></span></div>
    </div>
    <div class="donor-tags mb-1">${statusBadge}</div>
    <div class="donor-actions">
      ${st === "active" ? `<button class="btn btn-primary btn-sm" type="button" data-reveal-phone="${esc(r.phone)}">Reveal phone</button>` : ""}
      <button class="btn btn-outline btn-sm" type="button" data-share-wa="${esc(shareText)}">Share WhatsApp</button>
      <button class="btn btn-outline btn-sm" type="button" data-share-fb>Share Facebook</button>
      ${mine ? `<button class="btn btn-outline btn-sm" type="button" data-fulfill="${r.id}">Mark fulfilled</button>
                <button class="btn btn-danger btn-sm" type="button" data-remove="${r.id}">Delete</button>` : ""}
    </div>
  </article>`;
}

function render() {
  const wrap = $("#requestList");
  const showClosed = $("#showClosed").checked;

  let list = [...requests];
  if (!showClosed) list = list.filter((r) => statusOf(r) === "active");

  list.sort((a, b) => {
    const sa = statusOf(a), sb = statusOf(b);
    if (sa !== sb) return sa === "active" ? -1 : 1;
    if (sa === "active") return (a.neededBy || "").localeCompare(b.neededBy || "");
    return (b.createdAt?.toMillis?.() ?? 0) - (a.createdAt?.toMillis?.() ?? 0);
  });

  if (!list.length) {
    wrap.innerHTML = `
      <div class="empty-state" style="grid-column:1/-1">
        <svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
        <h3>${showClosed ? "No requests yet" : "No active emergency requests"}</h3>
        <p>${showClosed ? "When someone posts a request it will appear here." : "Wonderful — nobody needs urgent help right now."}</p>
      </div>`;
    return;
  }
  wrap.innerHTML = list.map(requestCardHTML).join("");
}

/* ---------- delegated actions ---------- */
document.addEventListener("click", async (e) => {
  const wa = e.target.closest("[data-share-wa]");
  if (wa) { waShare(wa.dataset.shareWa); return; }
  if (e.target.closest("[data-share-fb]")) { fbShare("https://bloodndc.github.io/requests.html"); return; }

  const fulfillBtn = e.target.closest("[data-fulfill]");
  if (fulfillBtn) {
    try {
      await updateDoc(doc(db, "requests", fulfillBtn.dataset.fulfill), { status: "fulfilled" });
      toast("Marked as fulfilled — congratulations and thank you! ❤", "success");
    } catch { toast("Could not update the request.", "error"); }
    return;
  }

  const removeBtn = e.target.closest("[data-remove]");
  if (removeBtn) {
    if (!confirm("Delete this request permanently?")) return;
    try {
      await deleteDoc(doc(db, "requests", removeBtn.dataset.remove));
      toast("Request deleted.", "success");
    } catch { toast("Could not delete the request.", "error"); }
  }
});

$("#showClosed").addEventListener("change", render);

/* ---------- modal ---------- */
const backdrop = $("#modalBackdrop");
function openModal() {
  backdrop.classList.add("open");
  document.body.style.overflow = "hidden";
  $("#rGroup").focus();
}
function closeModal() {
  backdrop.classList.remove("open");
  document.body.style.overflow = "";
}
$("#openModalBtn").addEventListener("click", openModal);
$("#closeModalBtn").addEventListener("click", closeModal);
backdrop.addEventListener("click", (e) => { if (e.target === backdrop) closeModal(); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeModal(); });

/* ---------- form ---------- */
$("#rGroup").innerHTML = '<option value="" disabled selected>Select</option>' +
  BLOOD_GROUPS.map((g) => `<option value="${g}">${g}</option>`).join("");
$("#rDeadline").min = new Date().toISOString().slice(0, 10);
const maxDate = new Date(Date.now() + 14 * 86400000);
$("#rDeadline").max = maxDate.toISOString().slice(0, 10);

function setInvalid(input, bad) {
  input.closest(".field")?.classList.toggle("invalid", bad);
  return !bad;
}
["rGroup", "rUnits", "rHospital", "rDeadline", "rContactName", "rPhone"].forEach((id) =>
  $("#" + id).addEventListener("input", (e) => setInvalid(e.target, false))
);

$("#requestForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const units = Number($("#rUnits").value);
  let ok = true;
  ok = setInvalid($("#rGroup"), !BLOOD_GROUPS.includes($("#rGroup").value)) && ok;
  ok = setInvalid($("#rUnits"), !(units >= 1 && units <= 10)) && ok;
  ok = setInvalid($("#rHospital"), !$("#rHospital").value.trim()) && ok;
  ok = setInvalid($("#rDeadline"), !$("#rDeadline").value || new Date($("#rDeadline").value) < new Date(new Date().toDateString())) && ok;
  ok = setInvalid($("#rContactName"), $("#rContactName").value.trim().length < 2) && ok;
  ok = setInvalid($("#rPhone"), !isValidBDPhone($("#rPhone").value)) && ok;

  const consentErr = $("#rConsentError");
  if (!$("#rConsent").checked) { consentErr.style.display = "block"; ok = false; }
  else consentErr.style.display = "none";

  if (!ok) { toast("Please fix the highlighted fields.", "error"); return; }

  const btn = $("#reqSubmitBtn");
  btn.disabled = true;
  btn.innerHTML = '<span class="spin" aria-hidden="true"></span> Posting…';

  try {
    if (!currentUid) currentUid = (await ensureAuth()).uid;

    await addDoc(collection(db, "requests"), {
      bloodGroup: $("#rGroup").value,
      units,
      hospital: $("#rHospital").value.trim(),
      area: $("#rArea").value.trim() || "Dhaka",
      neededBy: $("#rDeadline").value,
      contactName: $("#rContactName").value.trim(),
      phone: normalizePhone($("#rPhone").value),
      patient: $("#rPatient").value.trim() || "",
      status: "active",
      createdBy: currentUid,
      createdAt: serverTimestamp()
    });

    toast("Your request is live. We hope the blood is found quickly. 🤲", "success", 6000);
    $("#requestForm").reset();
    $("#rArea").value = "Dhaka";
    $("#rUnits").value = 1;
    closeModal();
  } catch (err) {
    showConnectError(err);
    toast("Could not post the request. Please try again.", "error");
  } finally {
    btn.disabled = false;
    btn.textContent = "Post request";
  }
});

/* ---------- load ---------- */
async function start() {
  try {
    const user = await ensureAuth();
    currentUid = user.uid;
    onSnapshot(
      collection(db, "requests"),
      (snap) => {
        requests = snap.docs.map((d) => ({ id: d.id, ...(d.data() || {}) }));
        render();
      },
      (err) => showConnectError(err)
    );
  } catch (err) {
    showConnectError(err);
    $("#requestList").innerHTML = "";
  }
}
start();
