/* donors.js — donor directory with search, filters, and nearest-first sorting */
import { collection, onSnapshot } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";
import { db, ensureAuth } from "./firebase.js";
import {
  $, BLOOD_GROUPS, ELIGIBILITY_DAYS, esc, eligibility, fmtDate, haversineKm, fmtKm,
  toast, waShare, showConnectError
} from "./ui.js";

const state = {
  donors: [],
  group: new URLSearchParams(location.search).get("group") || "",
  q: "",
  eligibleOnly: false,
  verifiedOnly: false,
  userLoc: null // {lat,lng}
};

/* ---------- rendering ---------- */
const initials = (name = "") =>
  name.trim().split(/\s+/).slice(0, 2).map((w) => (w[0] || "").toUpperCase()).join("") || "?";

function donorCardHTML(d) {
  const elig = eligibility(d.lastDonation);
  const avail = d.available !== false;
  const base = d.bloodGroup.replace("+", "").replace("-", "");

  const eligBadge = !avail
    ? '<span class="badge badge-gray">Unavailable</span>'
    : elig.eligible
      ? '<span class="badge badge-green">● Eligible now</span>'
      : `<span class="badge badge-amber">Eligible ${fmtDate(elig.nextDate)}</span>`;

  const verifiedBadge = d.verified
    ? '<span class="badge badge-blue" title="Verified by a moderator"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg> Verified</span>'
    : "";
  const distance = state.userLoc && d.lat != null && d.lng != null
    ? `<span class="badge badge-red">📍 ${fmtKm(haversineKm(state.userLoc, { lat: d.lat, lng: d.lng }))}</span>`
    : "";

  // eligibility progress bar
  let pct = 100, barCls = "ok";
  if (elig.known) {
    const days = Math.max(0, Math.floor((Date.now() - new Date(d.lastDonation).getTime()) / 86400000));
    pct = Math.min(100, Math.max(5, Math.round((days / ELIGIBILITY_DAYS) * 100)));
    barCls = elig.eligible ? "ok" : pct >= 70 ? "warn" : "";
  }
  const eligLabel = elig.known
    ? `Last donated <b>${fmtDate(d.lastDonation)}</b>`
    : "Donation history not shared";

  const tags = verifiedBadge + distance;
  const waText = `Assalamu alaikum! I found your contact on NDC Lifeline (Notre Dame College blood donor community). I need ${d.bloodGroup} blood urgently. Could you please help?`;

  return `
  <article class="card donor-card hover">
    <div class="donor-top">
      <div class="avatar-ring"><span class="avatar av-${base}">${initials(d.name)}</span></div>
      <div style="flex:1; min-width:0">
        <div class="donor-name">${esc(d.name)}</div>
        <div class="donor-meta">📍 ${esc(d.area || "Dhaka")}${d.city ? ", " + esc(d.city) : ""}</div>
      </div>
      <span class="bg-badge bg-${base}" aria-label="Blood group ${esc(d.bloodGroup)}">${esc(d.bloodGroup)}</span>
    </div>
    <div class="elig-line">
      <div class="elig-info"><span>${eligLabel}</span>${eligBadge}</div>
      <div class="elig-bar ${barCls}"><i style="width:${pct}%"></i></div>
    </div>
    ${tags ? `<div class="donor-tags">${tags}</div>` : ""}
    <div class="donor-actions">
      <button class="btn btn-primary btn-sm" style="flex:1" type="button" data-reveal-phone="${esc(d.phone)}" aria-label="Reveal phone number of ${esc(d.name)}">
        Reveal phone
      </button>
      <button class="btn btn-outline btn-sm" style="flex:1" type="button" data-wa="${esc(d.phone)}" data-wa-text="${esc(waText)}">WhatsApp</button>
    </div>
  </article>`;
}

function applyFilters() {
  let list = [...state.donors];
  const q = state.q.trim().toLowerCase();

  if (state.group) list = list.filter((d) => d.bloodGroup === state.group);
  if (q) list = list.filter((d) =>
    (d.name || "").toLowerCase().includes(q) ||
    (d.area || "").toLowerCase().includes(q) ||
    (d.city || "").toLowerCase().includes(q)
  );
  if (state.eligibleOnly) list = list.filter((d) => d.available !== false && eligibility(d.lastDonation).eligible);
  if (state.verifiedOnly) list = list.filter((d) => d.verified);

  // sort: nearest first when location known, else newest first
  if (state.userLoc) {
    list.sort((a, b) => {
      const da = a.lat != null && a.lng != null ? haversineKm(state.userLoc, a) : Infinity;
      const dbb = b.lat != null && b.lng != null ? haversineKm(state.userLoc, b) : Infinity;
      return da - dbb;
    });
  } else {
    list.sort((a, b) => (b.createdAt?.toMillis?.() ?? 0) - (a.createdAt?.toMillis?.() ?? 0));
  }
  return list;
}

function render() {
  const wrap = $("#donorList");
  const note = $("#resultNote");
  const list = applyFilters();

  if (!state.donors.length) {
    wrap.innerHTML = `
      <div class="empty-state" style="grid-column:1/-1">
        <svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2.7c3.6 4.6 7 8.3 7 12.3a7 7 0 1 1-14 0c0-4 3.4-7.7 7-12.3Z"/></svg>
        <h3>No donors yet</h3>
        <p>Be the first hero of this community.</p>
        <a class="btn btn-primary mt-2" href="register.html">Register as a donor</a>
      </div>`;
    note.textContent = "";
    return;
  }

  if (!list.length) {
    wrap.innerHTML = `
      <div class="empty-state" style="grid-column:1/-1">
        <h3>No matching donors</h3>
        <p>Try clearing filters, or post an emergency request so donors can reach out.</p>
        <a class="btn btn-primary mt-2" href="requests.html">Post emergency request</a>
      </div>`;
    note.textContent = "0 donors";
    return;
  }

  wrap.innerHTML = list.map(donorCardHTML).join("");
  note.textContent = `${list.length} donor${list.length === 1 ? "" : "s"}${state.group ? ` · ${state.group}` : ""}${state.userLoc ? " · sorted by distance" : ""}`;
}

/* ---------- filters UI ---------- */
function buildGroupFilter() {
  const wrap = $("#groupFilter");
  const chip = (g, active) =>
    `<button class="chip ${active ? "active" : ""}" type="button" data-group="${esc(g)}" aria-pressed="${active}">${g}</button>`;
  wrap.innerHTML = chip("All", !state.group) + BLOOD_GROUPS.map((g) => chip(g, state.group === g)).join("");

  wrap.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-group]");
    if (!btn) return;
    state.group = btn.dataset.group === "All" ? "" : btn.dataset.group;
    const url = new URL(location.href);
    if (state.group) url.searchParams.set("group", state.group); else url.searchParams.delete("group");
    history.replaceState(null, "", url);
    buildGroupFilter();
    render();
  });
}

/* ---------- events ---------- */
$("#searchInput").addEventListener("input", (e) => {
  state.q = e.target.value;
  render();
});
$("#eligibleOnly").addEventListener("change", (e) => { state.eligibleOnly = e.target.checked; render(); });
$("#verifiedOnly").addEventListener("change", (e) => { state.verifiedOnly = e.target.checked; render(); });

$("#nearestBtn").addEventListener("click", () => {
  if (state.userLoc) {
    state.userLoc = null;
    $("#nearestLabel").textContent = "Nearest first";
    toast("Distance sorting turned off.");
    render();
    return;
  }
  if (!navigator.geolocation) {
    toast("Geolocation is not supported by this browser.", "error");
    return;
  }
  $("#nearestLabel").textContent = "Locating…";
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      state.userLoc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      $("#nearestLabel").textContent = "✓ Nearest first";
      toast("Donors are now sorted by distance from you.", "success");
      render();
    },
    (err) => {
      $("#nearestLabel").textContent = "Nearest first";
      toast(
        err.code === err.PERMISSION_DENIED
          ? "Location permission denied — you can still search manually."
          : "Could not get your location. Try again.",
        "error"
      );
    },
    { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
  );
});

// WhatsApp share from donor cards (delegated)
document.addEventListener("click", (e) => {
  const btn = e.target.closest("[data-wa]");
  if (!btn) return;
  const phone = btn.dataset.wa;
  const text = btn.dataset.waText || "I need blood urgently. Found you on NDC Lifeline.";
  waShare(`${text} (Donor phone: ${phone})`);
});

/* ---------- load ---------- */
async function start() {
  try {
    await ensureAuth();
    onSnapshot(
      collection(db, "donors"),
      (snap) => {
        state.donors = snap.docs.map((d) => ({ id: d.id, ...(d.data() || {}) }));
        render();
      },
      (err) => showConnectError(err)
    );
  } catch (err) {
    showConnectError(err);
    $("#donorList").innerHTML = "";
  }
}

buildGroupFilter();
start();
