/* init.js — boots shared UI on every page */
import { initUI } from "./ui.js";
initUI();
