/* NDC Lifeline — shared UI helpers */

export const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
export const ELIGIBILITY_DAYS = 120; // ~4 months gap between donations

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

export function esc(str = "") {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

/* ---------- Toasts ---------- */
let toastWrap = null;
export function toast(message, type = "info", ms = 4200) {
  if (!toastWrap) {
    toastWrap = document.createElement("div");
    toastWrap.className = "toast-wrap";
    toastWrap.setAttribute("aria-live", "polite");
    document.body.appendChild(toastWrap);
  }
  const t = document.createElement("div");
  t.className = `toast ${type}`;
  t.textContent = message;
  toastWrap.appendChild(t);
  setTimeout(() => {
    t.classList.add("leaving");
    setTimeout(() => t.remove(), 320);
  }, ms);
}

/* ---------- Connection error banner ---------- */
export function showConnectError(err) {
  const banner = document.getElementById("connectBanner");
  if (!banner) return;
  const code = err?.code || "";
  let msg;
  if (code === "auth/operation-not-allowed") {
    msg = "Live data is unavailable: <strong>Anonymous sign-in is disabled</strong> for this Firebase project. Site owner — enable it in Firebase Console → Authentication → Sign-in method.";
  } else if (err?.message === "auth-timeout") {
    msg = "Still connecting to Firebase… If this persists, check your internet connection.";
  } else {
    msg = "Could not reach the live database right now. Some features may be unavailable. <span class='small'>(Owner: deploy <code>firestore.rules</code> and enable Anonymous sign-in — see README.)</span>";
  }
  banner.innerHTML = msg;
  banner.classList.add("show");
  console.warn("[NDC Lifeline] Firebase issue:", err);
}

/* ---------- Dates & eligibility ---------- */
export function fmtDate(input) {
  if (!input) return "—";
  let d = input;
  if (typeof input?.toDate === "function") d = input.toDate();
  else if (!(input instanceof Date)) d = new Date(input);
  if (isNaN(d)) return "—";
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}

export function daysBetween(a, b) {
  return Math.round((b - a) / 86400000);
}

/** Eligibility from a donor's last donation date (yyyy-mm-dd or Date). */
export function eligibility(lastDonation) {
  if (!lastDonation) return { eligible: true, known: false, nextDate: null };
  let d = lastDonation instanceof Date ? lastDonation : new Date(lastDonation);
  if (isNaN(d)) return { eligible: true, known: false, nextDate: null };
  const next = new Date(d.getTime() + ELIGIBILITY_DAYS * 86400000);
  const eligible = next <= new Date();
  return { eligible, known: true, nextDate: next, daysLeft: Math.max(0, daysBetween(new Date(), next)) };
}

/* ---------- Validation ---------- */
export function isValidBDPhone(phone) {
  return /^01[3-9]\d{8}$/.test(String(phone || "").replace(/[\s-]/g, ""));
}
export function normalizePhone(phone) {
  return String(phone || "").replace(/[\s-]/g, "");
}

/* ---------- Geo ---------- */
export function haversineKm(a, b) {
  const R = 6371, rad = (x) => (x * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}
export function fmtKm(km) {
  if (km == null) return "";
  return km < 1 ? `${Math.round(km * 1000)} m away` : `${km.toFixed(1)} km away`;
}
export function roundCoord(x, digits = 2) {
  const f = 10 ** digits;
  return Math.round(x * f) / f;
}

/* ---------- Sharing ---------- */
export function waShare(text) {
  window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank", "noopener");
}
export function fbShare(url) {
  window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, "_blank", "noopener");
}
export function copyText(text) {
  return navigator.clipboard?.writeText(text).then(
    () => toast("Copied to clipboard.", "success"),
    () => toast("Could not copy automatically.", "error")
  );
}

/* ---------- Count-up animation ---------- */
export function countUp(el, target, ms = 1100) {
  if (!el) return;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduce || !target) { el.textContent = target ?? 0; return; }
  const start = performance.now();
  const tick = (now) => {
    const p = Math.min(1, (now - start) / ms);
    el.textContent = Math.round(target * (1 - Math.pow(1 - p, 3)));
    if (p < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

/* ---------- Scroll reveal ---------- */
export function initReveal() {
  const els = $$(".reveal");
  if (!els.length) return;
  if (!("IntersectionObserver" in window)) {
    els.forEach((el) => el.classList.add("revealed"));
    return;
  }
  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add("revealed");
          io.unobserve(e.target);
        }
      });
    },
    { threshold: 0.12 }
  );
  els.forEach((el) => io.observe(el));
}

/* ---------- Phone reveal (delegated) ---------- */
export function initPhoneReveal() {
  document.addEventListener("click", (e) => {
    const btn = e.target.closest("[data-reveal-phone]");
    if (!btn) return;
    const phone = btn.getAttribute("data-reveal-phone");
    if (!phone) return;
    if (btn.dataset.revealed) {
      copyText(phone);
      return;
    }
    btn.dataset.revealed = "1";
    btn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.34 1.79.66 2.64a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.44-1.23a2 2 0 0 1 2.11-.45c.85.32 1.74.54 2.64.66A2 2 0 0 1 22 16.92z"/></svg> ${esc(phone)}`;
    btn.setAttribute("data-reveal-phone", phone);
    btn.title = "Click again to copy";
  });
}

/* ---------- Nav & footer boot ---------- */
let booted = false;
export function initUI() {
  if (booted) return;
  booted = true;

  // mobile nav
  const toggle = document.getElementById("navToggle");
  const nav = document.getElementById("mainNav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
    });
    nav.addEventListener("click", (e) => {
      if (e.target.tagName === "A") {
        nav.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  // active nav link
  const path = location.pathname.split("/").pop() || "index.html";
  const markActive = (scope) =>
    $$("a", scope).forEach((a) => {
      const href = a.getAttribute("href")?.split("/").pop();
      if (href === path || (path === "" && href === "index.html")) a.classList.add("active");
    });
  if (nav) markActive(nav);
  const bn = document.querySelector(".bottom-nav");
  if (bn) markActive(bn);

  // footer year
  const y = document.getElementById("year");
  if (y) y.textContent = new Date().getFullYear();

  initPhoneReveal();
  initReveal();
}
