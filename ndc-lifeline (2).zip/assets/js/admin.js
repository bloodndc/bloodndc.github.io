/* admin.js — moderated dashboard behind a shared admin code.
   Security model: Firestore rules enforce what writes are allowed.
   The admin code gates the UI; only UIDs listed in meta/admin.adminUids
   can perform admin-level writes (verify / delete). */
import {
  collection, onSnapshot, doc, getDoc, setDoc, updateDoc, deleteDoc, arrayUnion
} from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";
import { db, ensureAuth } from "./firebase.js";
import { $, $$, esc, fmtDate, eligibility, toast, showConnectError } from "./ui.js";

const META_REF = doc(db, "meta", "admin");
const SESSION_KEY = "ndc-lifeline-admin";

let user = null;
let adminUids = [];
let unsubDonors = null;
let unsubReqs = null;

const isAdminSession = () => sessionStorage.getItem(SESSION_KEY) === user?.uid;

/* ================= Gate ================= */
async function initGate() {
  try {
    user = await ensureAuth();
    const snap = await getDoc(META_REF);

    if (isAdminSession() && snap.exists() && snap.data().adminUids?.includes(user.uid)) {
      enterDashboard();
      return;
    }

    if (!snap.exists()) {
      $("#gateLogin").style.display = "none";
      $("#gateSetup").style.display = "block";
    } else {
      adminUids = snap.data().adminUids || [];
      if (adminUids.includes(user.uid)) {
        sessionStorage.setItem(SESSION_KEY, user.uid);
        enterDashboard();
      }
    }
  } catch (err) {
    showConnectError(err);
  }
}

$("#setupBtn").addEventListener("click", async () => {
  const code = $("#setupCode").value.trim();
  if (code.length < 6) { toast("Admin code must be at least 6 characters.", "error"); return; }
  const btn = $("#setupBtn");
  btn.disabled = true; btn.innerHTML = '<span class="spin" aria-hidden="true"></span> Creating…';
  try {
    await setDoc(META_REF, { adminCode: code, adminUids: [user.uid] });
    sessionStorage.setItem(SESSION_KEY, user.uid);
    toast("Admin created. Share the code with trusted moderators only.", "success");
    enterDashboard();
  } catch (err) {
    toast("Could not create admin: " + (err.message || "permission denied."), "error");
  } finally {
    btn.disabled = false; btn.textContent = "Create admin & unlock";
  }
});

$("#gateBtn").addEventListener("click", async () => {
  const code = $("#gateCode").value.trim();
  if (!code) { toast("Enter the admin code.", "error"); return; }
  const btn = $("#gateBtn");
  btn.disabled = true; btn.innerHTML = '<span class="spin" aria-hidden="true"></span> Checking…';
  try {
    const snap = await getDoc(META_REF);
    if (!snap.exists()) { toast("No admin exists yet — create one first.", "error"); return; }
    const data = snap.data();
    if (data.adminCode !== code) { toast("Wrong admin code.", "error"); return; }

    if (!data.adminUids?.includes(user.uid)) {
      await updateDoc(META_REF, { adminUids: arrayUnion(user.uid) });
    }
    sessionStorage.setItem(SESSION_KEY, user.uid);
    toast("Unlocked. Welcome, moderator! 🩸", "success");
    enterDashboard();
  } catch (err) {
    toast("Could not unlock: " + (err.message || "permission denied."), "error");
  } finally {
    btn.disabled = false; btn.textContent = "Unlock";
  }
});

$("#lockBtn").addEventListener("click", () => {
  sessionStorage.removeItem(SESSION_KEY);
  location.reload();
});

/* ================= Dashboard ================= */
function enterDashboard() {
  $("#gateView").style.display = "none";
  $("#dashView").style.display = "block";
  listenDonors();
  listenRequests();
}

function listenDonors() {
  unsubDonors?.();
  unsubDonors = onSnapshot(
    collection(db, "donors"),
    (snap) => {
      const donors = snap.docs.map((d) => ({ id: d.id, ...(d.data() || {}) }));
      donors.sort((a, b) => (b.createdAt?.toMillis?.() ?? 0) - (a.createdAt?.toMillis?.() ?? 0));
      $("#donorCount").textContent = donors.length;
      const wrap = $("#adminDonorList");
      if (!donors.length) {
        wrap.innerHTML = '<p class="muted small" style="padding:1rem">No donors registered yet.</p>';
        return;
      }
      wrap.innerHTML = donors.map((d) => {
        const elig = eligibility(d.lastDonation);
        return `
        <div class="admin-row">
          <div>
            <div class="cell-name">${esc(d.name)} ${d.verified ? "✓" : ""}</div>
            <div class="cell-sub">${esc(d.phone)} · ${esc(d.area || "")}${d.city ? ", " + esc(d.city) : ""}${d.available === false ? " · unavailable" : ""}</div>
          </div>
          <div class="hide-m"><b>${esc(d.bloodGroup)}</b></div>
          <div class="hide-m">${elig.known ? fmtDate(d.lastDonation) : "—"}</div>
          <div class="hide-m">
            ${d.verified ? '<span class="badge badge-blue">Verified</span>' : '<span class="badge badge-gray">Unverified</span>'}
            ${d.available !== false && elig.eligible ? '<span class="badge badge-green">Eligible</span>' : ""}
          </div>
          <div class="admin-actions">
            <button class="btn btn-outline btn-sm" type="button" data-verify="${d.id}" data-val="${!d.verified}">${d.verified ? "Unverify" : "Verify"}</button>
            <button class="btn btn-danger btn-sm" type="button" data-del-donor="${d.id}">Delete</button>
          </div>
        </div>`;
      }).join("");
    },
    (err) => showConnectError(err)
  );
}

function listenRequests() {
  unsubReqs?.();
  unsubReqs = onSnapshot(
    collection(db, "requests"),
    (snap) => {
      const reqs = snap.docs.map((d) => ({ id: d.id, ...(d.data() || {}) }));
      reqs.sort((a, b) => (b.createdAt?.toMillis?.() ?? 0) - (a.createdAt?.toMillis?.() ?? 0));
      $("#reqCount").textContent = reqs.length;
      const wrap = $("#adminReqList");
      if (!reqs.length) {
        wrap.innerHTML = '<p class="muted small" style="padding:1rem">No requests yet.</p>';
        return;
      }
      wrap.innerHTML = reqs.map((r) => {
        const expired = r.status === "active" && new Date(r.neededBy + "T23:59:59") < new Date();
        const st = r.status === "fulfilled" ? '<span class="badge badge-green">Fulfilled</span>'
          : expired ? '<span class="badge badge-gray">Expired</span>'
          : '<span class="badge badge-red">Active</span>';
        return `
        <div class="admin-row">
          <div>
            <div class="cell-name">${esc(r.hospital)}</div>
            <div class="cell-sub">${esc(r.contactName)} · ${esc(r.phone)} · ${r.units || 1} unit(s)${r.area ? " · " + esc(r.area) : ""}</div>
          </div>
          <div class="hide-m"><b>${esc(r.bloodGroup)}</b></div>
          <div class="hide-m">${fmtDate(r.neededBy)}</div>
          <div class="hide-m">${st}</div>
          <div class="admin-actions">
            ${r.status === "active" ? `<button class="btn btn-outline btn-sm" type="button" data-fulfill="${r.id}">Mark fulfilled</button>` : ""}
            <button class="btn btn-danger btn-sm" type="button" data-del-req="${r.id}">Delete</button>
          </div>
        </div>`;
      }).join("");
    },
    (err) => showConnectError(err)
  );
}

/* ---------- admin actions (delegated) ---------- */
document.addEventListener("click", async (e) => {
  const verify = e.target.closest("[data-verify]");
  if (verify) {
    try {
      await updateDoc(doc(db, "donors", verify.dataset.verify), { verified: verify.dataset.val === "true" });
      toast(verify.dataset.val === "true" ? "Donor verified. ✓" : "Verification removed.", "success");
    } catch { toast("Permission denied — admin write failed.", "error"); }
    return;
  }

  const delDonor = e.target.closest("[data-del-donor]");
  if (delDonor) {
    if (!confirm("Delete this donor permanently?")) return;
    try {
      await deleteDoc(doc(db, "donors", delDonor.dataset.delDonor));
      toast("Donor deleted.", "success");
    } catch { toast("Permission denied — admin delete failed.", "error"); }
    return;
  }

  const fulfill = e.target.closest("[data-fulfill]");
  if (fulfill) {
    try {
      await updateDoc(doc(db, "requests", fulfill.dataset.fulfill), { status: "fulfilled" });
      toast("Request marked fulfilled.", "success");
    } catch { toast("Could not update the request.", "error"); }
    return;
  }

  const delReq = e.target.closest("[data-del-req]");
  if (delReq) {
    if (!confirm("Delete this request permanently?")) return;
    try {
      await deleteDoc(doc(db, "requests", delReq.dataset.delReq));
      toast("Request deleted.", "success");
    } catch { toast("Permission denied — admin delete failed.", "error"); }
  }
});

/* ---------- tabs ---------- */
$$(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    $$(".tab-btn").forEach((b) => { b.classList.remove("active"); b.setAttribute("aria-selected", "false"); });
    btn.classList.add("active");
    btn.setAttribute("aria-selected", "true");
    $("#tab-donors").style.display = btn.dataset.tab === "donors" ? "block" : "none";
    $("#tab-requests").style.display = btn.dataset.tab === "requests" ? "block" : "none";
  });
});

/* ---------- change admin code ---------- */
$("#changeCodeBtn").addEventListener("click", async () => {
  const code = $("#newCode").value.trim();
  if (code.length < 6) { toast("New code must be at least 6 characters.", "error"); return; }
  try {
    await updateDoc(META_REF, { adminCode: code });
    $("#newCode").value = "";
    toast("Admin code updated.", "success");
  } catch { toast("Could not update the code.", "error"); }
});

initGate();
