# 🩸 NDC Lifeline — Blood Donor Community

A production-ready, student-run blood donor community website for
**Notre Dame College, Dhaka**.

- **Idea & Initiative:** Students of Notre Dame College, Batch 27, Group 11
- **Developed by:** [Foysal Mahmud](https://foysalcyber.github.io/)

---

## ✨ Features

| Area | What it does |
|---|---|
| 🔍 Donor search | Live search by name/area, filter by blood group, “eligible now only”, “verified only” |
| 📍 Nearest donor | Browser geolocation sorts donors by real distance (donors opt in at ~1 km precision) |
| ⏱ Eligibility engine | Auto-calculates the 120-day (4 month) donation gap and shows each donor's next eligible date |
| 🚨 Emergency board | Post urgent requests (group, units, hospital, needed-by date); shown on the homepage; one-tap WhatsApp/Facebook sharing |
| 🔒 Privacy-first | Phone numbers are masked until a visitor actively taps **Reveal phone** |
| ✅ Admin panel | Shared admin code + per-device unlock; verify/unverify donors, delete fake entries, manage requests |
| 📊 Stats | Live counters: donors, eligible-now, active requests, fulfilled requests |
| 📱 Responsive + accessible | Mobile-first layout, keyboard friendly, screen-reader landmarks, `prefers-reduced-motion` support |
| 🔎 SEO | Per-page titles/descriptions, canonical URLs, Open Graph, JSON-LD, `sitemap.xml` |

## 🧱 Stack

- Pure static HTML/CSS/JS (no build step) — perfect for **GitHub Pages**
- **Firebase Auth (anonymous)** + **Cloud Firestore** via the modular SDK v10 from CDN
- Security enforced server-side by `firestore.rules`

---

## 🚀 Setup (do these once — ~10 minutes)

### 1. Enable Anonymous sign-in
1. Open [Firebase Console](https://console.firebase.google.com) → project **blood-donate-ndc**
2. **Build → Authentication → Sign-in method**
3. Enable **Anonymous** → Save

> The site signs every visitor in anonymously. Donor records are keyed to
> that anonymous uid, which is why “edit my profile” works in the same browser.

### 2. Publish the security rules
1. **Build → Firestore Database → Rules**
2. Replace everything with the contents of [`firestore.rules`](firestore.rules)
3. Click **Publish**

### 3. Create the first admin
1. Open the deployed site's **`/admin.html`**
2. You'll see “No admin code exists yet” — create a code (min 6 chars)
3. Share that code only with trusted moderators. Each moderator opens
   `/admin.html`, enters the code, and their device is unlocked
   (their uid is appended to `meta/admin.adminUids` — enforced by rules).

> Change the shared code anytime from the dashboard (“Change admin code”).
> Already-unlocked devices stay unlocked on that device/browser.

### 4. Deploy to GitHub Pages
This folder is the complete site root (designed for the `bloodndc.github.io` repo):

```bash
git clone https://github.com/bloodndc/bloodndc.github.io.git deploy
# copy everything from this folder into deploy/ (replace old files)
cd deploy
git add -A && git commit -m "NDC Lifeline v2"
git push
```

GitHub Pages serves `index.html` automatically. The canonical/OG URLs already
point to `https://bloodndc.github.io/`.

### 5. Test locally (optional)
ES modules need an HTTP server — don't open the HTML files directly:

```bash
cd ndc-lifeline
python3 -m http.server 8080
# → http://localhost:8080
```

---

## 🗂 Project structure

```
├── index.html            # Home: hero, live stats, urgent requests, eligibility checker
├── donors.html           # Donor directory + filters + nearest-first
├── register.html         # Donor registration / self-service profile update
├── requests.html         # Emergency board + post-request modal
├── about.html            # Initiative story + credits (JSON-LD)
├── faq.html              # Donation & platform FAQ
├── contact.html          # Contact + privacy policy
├── admin.html            # Moderation dashboard (code-gated)
├── 404.html              # Styled 404 for GitHub Pages
├── firestore.rules       # ⬅ paste into Firebase Console
├── sitemap.xml · robots.txt
└── assets/
    ├── css/style.css     # Design system (red-centric, light theme)
    └── js/
        ├── firebase.js   # Config + silent anonymous sign-in
        ├── ui.js         # Shared helpers (toast, validation, eligibility, geo…)
        ├── init.js       # Nav/footer boot (every page)
        ├── home.js · donors.js · register.js · requests.js · admin.js
```

## 🗃 Firestore data model

- `donors/{uid}` — `name, bloodGroup, phone, area, city, lastDonation (yyyy-mm-dd|null), available, lat?, lng?, verified, createdBy, createdAt, updatedAt`
- `requests/{id}` — `bloodGroup, units, hospital, area, neededBy (yyyy-mm-dd), contactName, phone, patient?, status: active|fulfilled, createdBy, createdAt`
- `meta/admin` — `adminCode, adminUids[]`

## 🔧 Customize before launch

1. **Contact email** — `contact.html` uses `ndclifeline.team@gmail.com`; replace with the group's real address.
2. **Admin code** — choose a strong one when you create it on `/admin.html`.
3. Old demo data in Firestore from previous versions can be deleted from the Firebase Console.

## 🛡 Notes

- Firebase web config keys are public by design; real protection comes from
  the Firestore rules above.
- Eligibility uses a 120-day whole-blood donation gap (common BD guideline).
- The site never collects money or medical records.

---

Made with ❤ by the students of Notre Dame College, Batch 27 · Group 11.
